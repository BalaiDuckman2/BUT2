public interface Observateur {
    void miseAJour(String message);
}
